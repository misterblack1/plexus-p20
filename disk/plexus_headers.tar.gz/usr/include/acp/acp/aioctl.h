/* SID */
/* @(#)aioctl.h	5.1 4/22/86 */

/* Plexus specific ioctl calls for ACP's */
#define APIOC	('P'<<8)	/* set process group of tty line to 0 */
#define PBRDRST (APIOC|2)

