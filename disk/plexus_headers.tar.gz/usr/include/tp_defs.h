/*  */
/* @(#)tp_defs.h	5.1 4/22/86 */

/*	@(#)tp_defs.h	1.1	*/
/*	3.0 SID #	1.1	*/
char	mt[]	= "/dev/mt0";
char	tc[]	= "/dev/tapx";
int	flags	= flu;
char	mheader[] = "/usr/mdec/mboot";
char	theader[] = "/usr/mdec/tboot";
