/* SID @(#)maxuser32.h	5.1 */
#define MAXUSER 32
