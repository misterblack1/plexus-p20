/* SID @(#)lock.h	5.1 */
/* @(#)lock.h	6.1 */
/*
 * flags for locking procs and texts
 */
#define	UNLOCK	 0
#define	PROCLOCK 1
#define	TXTLOCK	 2
#define	DATLOCK	 4
