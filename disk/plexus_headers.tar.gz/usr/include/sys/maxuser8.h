/* @(#)maxuser8.h	5.1 SID */
#define MAXUSER 8
