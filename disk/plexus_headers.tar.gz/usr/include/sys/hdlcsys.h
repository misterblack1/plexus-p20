
/* SID @(#)hdlcsys.h	5.1 */
/* @(#)hdlcsys.h	6.1 */

#define PCATCH	0400
#define PMASK	0177

