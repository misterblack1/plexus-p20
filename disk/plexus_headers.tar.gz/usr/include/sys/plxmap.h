/* SID @(#)plxmap.h	5.1 */
/* @(#)plxmap.h	6.3 */

struct imap
{
	ushort	m_size;
	unsigned m_addr;
};
