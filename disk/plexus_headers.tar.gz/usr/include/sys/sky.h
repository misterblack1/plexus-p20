/* SID @(#)sky.h	5.1 */

	/* Include file with sky addresses */
#define comreg (MBILO + 0x8000)
#define stcreg (MBILO + 0x8002)
#define dt1reg (MBILO + 0x8004)
#define dt2reg (MBILO + 0x8006)
#define mc1reg (MBILO + 0x8008)
#define mc2reg (MBILO + 0x800a)
#define MAXADDR 0x1c33		/*last address in the microcode*/
