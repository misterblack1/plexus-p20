/* SID @(#)uparm.h	5.1 */

#define libpath(file) "/usr/lib/file"
#define loclibpath(file) "/usr/local/lib/file" 
#define binpath(file) "/usr/bin/file"
#define usrpath(file) "/usr/file"
#define E_TERMCAP	"/etc/termcap"
#define B_CSH		"/usr/plx/csh"
