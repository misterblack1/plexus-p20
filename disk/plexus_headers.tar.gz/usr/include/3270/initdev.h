
/* 
 * SID @(#)initdev.h	5.1
 */

#include <stdio.h>
#include <signal.h>

#include <fcntl.h>
#include <sys/ioctl.h>

#include <termio.h>

