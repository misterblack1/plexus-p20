/*  */
/* SID @(#)sizes.h	5.1 */
/* @(#)sizes.h	1.8 5/18/84 */



		/* sizing information for tables and other things */


#define N_CONNECT 21		/* number of connections/process */

#define N_CPH     10		/* number of characters per host name */



#define MAXUSERHDR	0x98	/* maximum user header size */
#define MAXUSERDATA	1024	/* maximum user data area (scattered) */
