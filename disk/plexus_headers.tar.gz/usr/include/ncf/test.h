/*  */
/* SID @(#)test.h	5.1 */
/* @(#)test.h	1.3 5/1/83 */



	/*---------------------------*\
	| includes for testing of ncf |
	\*---------------------------*/

#define NATTACH  0
#define NOPEN    1
#define NREAD    2
#define NWRITE   3
#define NIOCTL   4
#define NCLOSE   5
#define NDETACH  6
