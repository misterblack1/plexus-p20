/* @(#)_sccsid.h	5.1 SID */
#define _SCCSID(w,g) 
