/*  */
/* @(#)errno.h	5.1 4/22/86 */

/*	@(#)errno.h	1.2	*/
/*	3.0 SID #	1.3	*/
/*
 * Error codes
 */

#include <sys/errno.h>
extern int errno;
