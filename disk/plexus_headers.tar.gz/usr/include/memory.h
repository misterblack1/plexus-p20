/*  */
/* @(#)memory.h	5.1 4/22/86 */

/*	@(#)memory.h	1.2	*/
extern char
	*memccpy(),
	*memchr(),
	*memcpy(),
	*memset();
extern int memcmp();
