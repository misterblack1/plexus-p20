/*  */
/* @(#)string.h	5.1 4/22/86 */

/*	@(#)string.h	1.2	*/
extern char
	*strcpy(),
	*strncpy(),
	*strcat(),
	*strncat(),
	*strchr(),
	*strrchr(),
	*strpbrk(),
	*strtok();
extern int
	strcmp(),
	strncmp(),
	strlen(),
	strspn(),
	strcspn();
