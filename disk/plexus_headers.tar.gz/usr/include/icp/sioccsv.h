
/* SID @(#)sioccsv.h	5.1 */
/* @(#)sioccsv.h	1.0 11/14/84 */


/*
 * constants used by the c calling sequence implementation.
 */

#define	NUMSAVEREG	6	/* the number of user register variables */
#define	FIRSTSAVEREG	r8	/* first user save register */
#define	LENSAVEREG	2*NUMSAVEREG

