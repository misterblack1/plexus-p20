/* SID @(#)whoami.h	5.1 */

#define	sysname	"where I am"
