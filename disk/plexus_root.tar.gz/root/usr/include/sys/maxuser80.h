/* SID */
/* @(#)maxuser80.h	5.1 4/22/86 */

#define MAXUSER 80
