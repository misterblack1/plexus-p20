/* SID @(#)plxparam.h	5.1 */
/* @(#)plxparam.h	6.1 */

/*
 * signals
 * don't change
 */
#define NSIG	20	/* 21 ifdef PNETVT */

