/* SID @(#)maxuser16.h	5.1 */
#define MAXUSER 16
