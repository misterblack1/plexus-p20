
/* SID @(#)hdlc.h	5.1 */
/* @(#)hdlc.h	1.0 */

#define HDLCK	4	/* number of max hdlc ICPs		*/

#define ENOMSG	35	/* No message of desired type		*/
#define EIDRM	36	/* Identifier removed			*/
#define ECHRNG	37	/* Channel number out of range		*/
#define EL2NSYNC 38	/* Level 2 not synchronized		*/
#define EL3HLT	39	/* Level 3 halted			*/
#define EL3RST	40	/* Level 3 reset			*/
#define ELNRNG	41	/* Link number out of range		*/
#define EUNATCH	42	/* Protocol driver not attached		*/
#define ENOCSI	43	/* No CSI structure available		*/
#define EL2HLT	44	/* Level 2 halted			*/

