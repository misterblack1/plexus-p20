/*  */
/* @(#)termio.h	5.1 4/22/86 */

/*	@(#)termio.h	1.1	*/
/*	3.0 SID #	1.3	*/
#include <sys/termio.h>
