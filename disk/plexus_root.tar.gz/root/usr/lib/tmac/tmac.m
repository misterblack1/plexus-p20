'\"	@(#)tmac.m	1.2
.if n .so /usr/lib/macros/mmn
.if t .so /usr/lib/macros/mmt
