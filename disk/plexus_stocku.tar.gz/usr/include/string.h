/*  */
/* @(#)string.h	1.1 4/19/84 */

/*	@(#)string.h	1.2	*/
extern char
	*strcpy(),
	*strncpy(),
	*strcat(),
	*strncat(),
	*strchr(),
	*strrchr(),
	*strpbrk(),
	*strtok();
extern int
	strcmp(),
	strncmp(),
	strlen(),
	strspn(),
	strcspn();
