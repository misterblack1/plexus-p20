
/* SID @(#)hdlcicp.h	1.1 */
/* @(#)hdlcicp.h	1.0 11/14/84 */

/* The following relate to HDLC */
#define HDLCRTNX 20		/* HDLC return xmit buffer from ICP */
#define HDLCRTNR 21		/* HDLC return recv buffer from ICP */

