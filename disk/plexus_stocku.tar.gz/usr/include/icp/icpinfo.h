
/* SID @(#)icpinfo.h	1.1 */
/* @(#)icpinfo.h	1.0 11/14/84 */

extern long canch;
extern long outch;
extern long rawch;
extern long rcvint;
