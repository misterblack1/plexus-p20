
/* SID @(#)siocunix.h	1.2 */
/* @(#)siocunix.h	1.0 11/14/84 */


/*
 * sio related defines
 */

#define NUMICP  5		/* number of icps in chassis */
#define	NUMSIO	8		/* number of sio channels  0-7 */
#define DNLDUNIT 9		/* unit # for down load port in icp */
#define PIOUNIT 8		/* parallel io port # in icp */
#define	CONSOLE	0		/* unit number of console device */
