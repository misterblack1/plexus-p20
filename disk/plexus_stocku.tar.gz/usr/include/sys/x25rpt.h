/* SID @(#)x25rpt.h	1.1 */
/* @(#)x25rpt.h	1.2 */
/*	x25rpt.h 1.1 of 9/1/81
 */

#define S_FAIL	01
#define S_SYNC	02
#define R_INFO	03
#define R_N2MAX	04
#define R_DISC	05
