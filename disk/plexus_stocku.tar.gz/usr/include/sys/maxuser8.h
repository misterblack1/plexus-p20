/* @(#)maxuser8.h	1.1 SID */
#define MAXUSER 8
