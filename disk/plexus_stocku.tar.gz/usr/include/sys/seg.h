/* SID @(#)seg.h	1.1 */
/* @(#)seg.h	6.1 */
/*
 * Memory management addresses and bits
 */

#define	RO	PG_NOWR		/* access abilities */
#define	RW	0
