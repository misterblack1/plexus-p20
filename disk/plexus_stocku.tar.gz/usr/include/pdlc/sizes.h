/*  */
/* SID @(#)sizes.h	1.1 */
/* @(#)sizes.h	1.4 1/2/84 */



	/*-----------------------------------------*\
	| sizes of various data blocks used in PDLC |
	\*-----------------------------------------*/

#define CBSIZE	512	/* number of characters in cb data area */
#define N_SUQ    45	/* size of s/u frame queue used by et daemon */
#define K	  4	/* size of window allowed */
