/* @(#)_sccsid.h	1.2 SID */
#define _SCCSID(w,g) 
