
/* 
 * SID @(#)bisync.h	1.1
 */

#define SOH 0x01
#define STX 0x02
#define ETX 0x03
#define DLE 0x10
#define ENQ 0x2d
#define ETB 0x26
#define NAK 0x3d
#define PAD 0xff
#define X70 0x70
#define SYNC 0x32
#define CKSEQ 0x80
#define NOCK 0x90
#define RSSEQ 0xa0
#define WAITBIT 0x40
