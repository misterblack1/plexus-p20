/*  */
/* @(#)memory.h	1.1 4/19/84 */

/*	@(#)memory.h	1.2	*/
extern char
	*memccpy(),
	*memchr(),
	*memcpy(),
	*memset();
extern int memcmp();
