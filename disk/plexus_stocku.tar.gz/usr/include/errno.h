/*  */
/* @(#)errno.h	1.1 4/19/84 */

/*	@(#)errno.h	1.2	*/
/*	3.0 SID #	1.3	*/
/*
 * Error codes
 */

#include <sys/errno.h>
extern int errno;
