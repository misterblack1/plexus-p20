/* SID @(#)etconf.h	1.1 */
/*  */
/* @(#)etconf.h	1.3 5/1/83 */



	/* configuration information for ethernet controller */

#define	ETINIT	(1<<1)		/* mask for enabling multibus interrupts */
